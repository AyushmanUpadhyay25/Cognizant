import React from 'react';
import Posts from './Posts';   // ← Posts.js must exist here

function App() {
  return (
    <div className="App">
      <Posts />
    </div>
  );
}

export default App;
